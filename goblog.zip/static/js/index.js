document.getElementsByClassName("more-ico")[0].onclick=function(){
    window.scrollBy(0,document.getElementsByClassName("section-3")[0].style.clientHeight);
}